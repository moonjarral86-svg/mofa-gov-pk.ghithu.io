<?php
include '../config.php';
if($_POST){
    $name=$_POST['name'];
    $passport=$_POST['passport'];
    $code=rand(100000,999999);
    mysqli_query($conn,"INSERT INTO records(name,passport,code) VALUES('$name','$passport','$code')");
    echo "Record Added. Verification Code: ".$code;
}
?>
<form method="POST">
<input type="text" name="name" placeholder="Name"><br><br>
<input type="text" name="passport" placeholder="Passport"><br><br>
<button type="submit">Add Record</button>
</form>
