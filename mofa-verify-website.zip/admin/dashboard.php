<?php
session_start();
if(!$_SESSION['admin']){ header("Location: login.php"); }
?>
<h2>Admin Dashboard</h2>
<a href="add-record.php">Add New Record</a>
