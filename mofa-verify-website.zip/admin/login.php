<?php
session_start();
if($_POST){
    if($_POST['username']=="admin" && $_POST['password']=="Admin@123"){
        $_SESSION['admin']=true;
        header("Location: dashboard.php");
    }
}
?>
<form method="POST">
<h3>Admin Login</h3>
<input type="text" name="username" placeholder="Username"><br><br>
<input type="password" name="password" placeholder="Password"><br><br>
<button type="submit">Login</button>
</form>
