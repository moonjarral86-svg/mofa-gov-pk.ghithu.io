<?php ?>
<!DOCTYPE html>
<html>
<head>
    <title>MOFA Document Verification</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="header">
    <h2>MINISTRY OF FOREIGN AFFAIRS</h2>
    <h3>GOVERNMENT OF PAKISTAN</h3>
</div>

<div class="container">
    <h3>Document Verification</h3>
    <form action="verify.php" method="GET">
        <input type="text" name="code" placeholder="Enter Verification Code" required>
        <button type="submit">Verify</button>
    </form>
</div>
</body>
</html>
