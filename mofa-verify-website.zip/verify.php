<?php
include 'config.php';
$code = $_GET['code'];

$query = mysqli_query($conn, "SELECT * FROM records WHERE code='$code'");
$data = mysqli_fetch_assoc($query);
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="header">
    <h2>MINISTRY OF FOREIGN AFFAIRS</h2>
    <h3>GOVERNMENT OF PAKISTAN</h3>
</div>

<div class="container">
<?php if($data){ ?>
    <h3>Verification Successful</h3>
    <p><strong>Name:</strong> <?php echo $data['name']; ?></p>
    <p><strong>Passport:</strong> <?php echo $data['passport']; ?></p>
    <p><strong>Status:</strong> Attested</p>
<?php } else { ?>
    <h3 style="color:red;">Invalid Verification Code</h3>
<?php } ?>
</div>
</body>
</html>
